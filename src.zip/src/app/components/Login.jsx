import { useState, useRef, useEffect } from 'react';
import { Wallet, LogIn } from 'lucide-react';

export function Login({ onLogin, onShowSignup }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const usernameRef = useRef(null);

  useEffect(() => {
    usernameRef.current?.focus();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    const savedUser = JSON.parse(localStorage.getItem('expenseUser'));

    if (!username.trim() || !password.trim()) {
      setError('Username and password are required.');
      return;
    }

    if (!savedUser) {
      setError('No account found. Please create an account first.');
      return;
    }

    if (
      username === savedUser.username &&
      password === savedUser.password
    ) {
      onLogin(username);
    } else {
      setError('Invalid username or password.');
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 text-[#ffd700]">
      <div className="w-full max-w-md rounded-[30px] border border-[#b89100] bg-[#050505]/95 p-8 shadow-[0_30px_80px_-30px_rgba(255,215,0,0.25)] backdrop-blur-sm">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center rounded-3xl border border-[#b89100] bg-[#111111] px-4 py-2 text-xs uppercase tracking-[0.3em] font-bold text-[#ffd700] shadow-inner shadow-[#b89100]/20">
            Dan Pati Vault
          </div>
          <h1 className="mt-6 text-4xl font-black tracking-tight text-[#ffd700] drop-shadow-[0_8px_25px_rgba(255,215,0,0.25)]">
            Dan Pati Login
          </h1>
          <p className="mt-3 text-sm text-[#f0d975]">
            Spend Smarter, Grow Faster
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label
              htmlFor="username"
              className="block text-sm font-semibold uppercase tracking-[0.12em] text-[#ffd700] mb-2"
            >
              Username
            </label>

            <input
              ref={usernameRef}
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter username"
              className="w-full rounded-2xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
              required
            />
          </div>

          <div>
            <label
              htmlFor="password"
              className="block text-sm font-semibold uppercase tracking-[0.12em] text-[#ffd700] mb-2"
            >
              Password
            </label>

            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              className="w-full rounded-2xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
              required
            />
            <div className="mt-3 text-sm text-[#ffd700]">
              Don&apos;t have an account?{' '}
              <button
                type="button"
                onClick={onShowSignup}
                className="font-semibold text-[#ffd700] underline-offset-4 transition hover:text-white"
              >
                Create one now.
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#ffd700] px-4 py-3 text-sm font-bold uppercase tracking-[0.15em] text-black shadow-[0_16px_45px_-18px_rgba(0,0,0,0.9)] transition hover:bg-[#e6c400]"
          >
            <LogIn className="w-5 h-5" />
            Enter the Vault
          </button>
        </form>
      </div>
    </div>
  );
}
import { Wallet } from 'lucide-react';
import { ExpenseItem } from './ExpenseItem';

export function ExpenseList({
  expenses,
  filterCategory,
  filterType,
  categories,
  onFilterChange,
  onFilterTypeChange,
  onDeleteExpense
}) {
  return (
    <div className="bg-[#090909] rounded-2xl p-6 shadow-lg border border-[#b89100]">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <h2 className="text-[#ffd700]">Recent Transactions</h2>

        <div className="flex flex-wrap items-center gap-2">
          <label htmlFor="filterType" className="text-[#ffd700] whitespace-nowrap">
            Type:
          </label>
          <select
            id="filterType"
            value={filterType}
            onChange={(e) => onFilterTypeChange(e.target.value)}
            className="px-3 py-2 rounded-xl border border-[#b89100] bg-[#080808] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40 text-[#ffd700] transition-all"
          >
            <option value="All">All</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
          </select>

          <label htmlFor="filter" className="text-[#ffd700] whitespace-nowrap ml-2">
            Category:
          </label>
          <select
            id="filter"
            value={filterCategory}
            onChange={(e) => onFilterChange(e.target.value)}
            className="px-3 py-2 rounded-xl border border-[#b89100] bg-[#080808] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40 text-[#ffd700] transition-all"
          >
            <option value="All">All Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat} className="bg-[#080808] text-[#ffd700]">
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {expenses.length === 0 ? (
        <div className="text-center py-12">
          <Wallet className="w-16 h-16 text-[#ffd700]/60 mx-auto mb-4" />
          <p className="text-[#ffd700]">No transactions found</p>
          <p className="text-[#d8c57f]">Add your first transaction to get started</p>
        </div>
      ) : (
        <div className="space-y-3">
          {expenses.map((expense) => (
            <ExpenseItem
              key={expense.id}
              expense={expense}
              onDelete={onDeleteExpense}
            />
          ))}
        </div>
      )}
    </div>
  );
}

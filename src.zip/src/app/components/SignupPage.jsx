import { useState } from 'react';

export default function SignupPage() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // ERROR STATES
  const [usernameError, setUsernameError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

  const handleSignup = (e) => {
    e.preventDefault();

    // RESET ERRORS
    setUsernameError('');
    setPasswordError('');

    let valid = true;

    // USERNAME VALIDATION
    if (username.length < 5) {
      setUsernameError(
        'Username must contain at least 5 characters'
      );
      valid = false;
    } else if (username.includes(' ')) {
      setUsernameError(
        'Username cannot contain spaces'
      );
      valid = false;
    }

    // PASSWORD VALIDATION
    if (!passwordRegex.test(password)) {
      setPasswordError(
        'Password must contain uppercase, lowercase, number and minimum 8 characters'
      );
      valid = false;
    }

    if (!valid) return;

    // SAVE USER DATA
    const userData = {
      fullName,
      email,
      username,
      password,
    };

    localStorage.setItem(
      'expenseUser',
      JSON.stringify(userData)
    );

    alert('Account created successfully!');

    // CLEAR INPUTS
    setFullName('');
    setEmail('');
    setUsername('');
    setPassword('');
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4 text-[#ffd700]">
      <div className="bg-[#050505] shadow-2xl rounded-2xl p-8 w-full max-w-md border border-[#b89100]">
        
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-[#ffd700]">
            Dan Pati
          </h1>

          <p className="text-[#f0d975] mt-2">
            Create your secure account in the black-gold vault.
          </p>
        </div>

        <form
          onSubmit={handleSignup}
          className="space-y-4"
        >
          {/* FULL NAME */}
          <div>
            <label className="block text-sm font-medium text-[#ffd700] mb-1">
              Full Name
            </label>

            <input
              type="text"
              value={fullName}
              onChange={(e) =>
                setFullName(e.target.value)
              }
              placeholder="Enter your name"
              className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
              required
            />
          </div>

          {/* EMAIL */}
          <div>
            <label className="block text-sm font-medium text-[#ffd700] mb-1">
              Email
            </label>

            <input
              type="email"
              value={email}
              onChange={(e) =>
                setEmail(e.target.value)
              }
              placeholder="Enter your email"
              className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
              required
            />
          </div>

          {/* USERNAME */}
          <div>
            <label className="block text-sm font-medium text-[#ffd700] mb-1">
              Username
            </label>

            <input
              type="text"
              value={username}
              onChange={(e) =>
                setUsername(e.target.value)
              }
              placeholder="Choose a username"
              className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
              required
            />

            {usernameError && (
              <p className="text-red-500 text-sm mt-1">
                {usernameError}
              </p>
            )}
          </div>

          {/* PASSWORD */}
          <div>
            <label className="block text-sm font-medium text-[#ffd700] mb-1">
              Password
            </label>

            <input
              type="password"
              value={password}
              onChange={(e) => {
                const value = e.target.value;
                setPassword(value);
                if (passwordError && passwordRegex.test(value)) {
                  setPasswordError('');
                }
              }}
              placeholder="Create password"
              className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
              required
            />

            {passwordError && (
              <p className="text-red-500 text-sm mt-1">
                {passwordError}
              </p>
            )}
          </div>

          {/* BUTTON */}
          <button
            type="submit"
            className="w-full rounded-xl bg-[#b89100] py-3 text-black font-semibold uppercase tracking-[0.04em] shadow-[0_16px_40px_-18px_rgba(255,215,0,0.6)] transition hover:bg-[#ffd700]"
          >
            Sign Up
          </button>
        </form>
      </div>
    </div>
  );
}
import { useMemo, useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';

export function ExpenseChart({ transactions }) {
  const [selectedView, setSelectedView] = useState('income');

  const chartData = useMemo(() => {
    const grouped = transactions.reduce((acc, transaction) => {
      const day = transaction.date;

      if (!acc[day]) {
        acc[day] = { date: day, income: 0, expense: 0 };
      }

      if (transaction.type === 'income') {
        acc[day].income += transaction.amount;
      } else {
        acc[day].expense += transaction.amount;
      }

      return acc;
    }, {});

    return Object.values(grouped)
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-15)
      .map((item) => ({
        name: new Date(item.date).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
        }),
        income: item.income,
        expense: item.expense,
      }));
  }, [transactions]);

  const chartTitle = selectedView === 'income' ? 'Income Trend' : 'Expense Trend';
  const lineColor = selectedView === 'income' ? '#10b981' : '#ef4444';

  return (
    <div className="bg-[#090909] rounded-2xl shadow-xl p-5 border border-[#b89100]">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-5">
        <div>
          <h2 className="text-2xl font-bold text-[#ffd700]">Live Linear Graph</h2>
          <p className="text-[#f0d975] mt-1">
            Separate income and expense trends in the gold vault.
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => setSelectedView('income')}
            className={`px-4 py-2 rounded-full font-semibold transition ${
              selectedView === 'income'
                ? 'bg-[#b89100] text-black'
                : 'bg-[#1a1a1a] text-[#ffd700] hover:bg-[#2c2c2c]'
            }`}
          >
            Income
          </button>

          <button
            type="button"
            onClick={() => setSelectedView('expense')}
            className={`px-4 py-2 rounded-full font-semibold transition ${
              selectedView === 'expense'
                ? 'bg-[#b89100] text-black'
                : 'bg-[#1a1a1a] text-[#ffd700] hover:bg-[#2c2c2c]'
            }`}
          >
            Expense
          </button>
        </div>
      </div>

      <div className="mb-4 text-sm text-[#f0d975]">
        Viewing: <span className="font-semibold text-[#ffd700]">{chartTitle}</span>
      </div>

      {chartData.length === 0 ? (
        <div className="text-center py-20 text-[#d8c57f]">
          Add a transaction to generate a live chart.
        </div>
      ) : (
        <div className="w-full h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#444" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#ffd700' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#ffd700' }} tickFormatter={(value) => `₹${value}`} axisLine={false} tickLine={false} />
              <Tooltip formatter={(value) => [`₹${value}`, 'Amount']} contentStyle={{ backgroundColor: '#111', borderColor: '#b89100', color: '#ffd700' }} labelStyle={{ color: '#ffd700' }} />
              <Legend wrapperStyle={{ color: '#ffd700' }} />
              <Line
                type="monotone"
                dataKey={selectedView}
                stroke={lineColor === '#10b981' ? '#ffd700' : '#ffb347'}
                strokeWidth={3}
                dot={{ r: 4, fill: '#ffd700' }}
                activeDot={{ r: 6, fill: '#ffd700' }}
                name={chartTitle}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
import { useState } from 'react';

export function SavingsGoal({ balance }) {
  const [goal, setGoal] = useState(50000);
  const savedAmount = Math.max(balance, 0);
  const progress = goal > 0 ? Math.min((savedAmount / goal) * 100, 100) : 0;
  const remainingToGoal = Math.max(goal - savedAmount, 0);
  const availableForExpenses = Math.max(savedAmount - goal, 0);

  return (
    <div className="bg-[#090909] rounded-2xl shadow-xl p-5 border border-[#b89100]">
      <h2 className="text-xl font-semibold text-[#ffd700] mb-4">
        Savings Goal
      </h2>

      <div className="mb-3">
        <label className="block text-[#ffd700] mb-2">
          Set Goal Amount
        </label>

        <input
          type="number"
          min="0"
          value={goal}
          onChange={(e) => setGoal(Math.max(Number(e.target.value), 0))}
          className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
        />
      </div>

      <div className="mb-3">
        <div className="flex justify-between mb-2 text-sm text-[#ffd700]">
          <span>Saved: ₹{savedAmount.toFixed(2)}</span>
          <span>Goal: ₹{goal.toFixed(2)}</span>
        </div>

        <div className="w-full bg-[#111] rounded-full h-3 overflow-hidden">
          <div
            className="bg-[#ffd700] h-4 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      <div className="mb-3 text-sm text-[#f0d975]">
        {goal === 0 ? (
          'Set a savings goal to track your progress.'
        ) : savedAmount <= 0 ? (
          'No savings available yet. Add income and reduce expenses.'
        ) : progress >= 100 ? (
          `🎉 Goal reached! You can use ₹${availableForExpenses.toFixed(2)} for extra expenses.`
        ) : (
          `Save ₹${remainingToGoal.toFixed(2)} more to reach your goal.`
        )}
      </div>

      {availableForExpenses > 0 && (
        <div className="rounded-xl bg-[#111] p-4 text-sm text-[#ffd700] border border-[#b89100]">
          Available for expenses: <span className="font-semibold">₹{availableForExpenses.toFixed(2)}</span>
        </div>
      )}
    </div>
  );
}
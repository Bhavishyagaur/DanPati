import { useMemo, useState } from 'react';
import { FilePlus, Trash2 } from 'lucide-react';

export function NotesDashboard() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [notes, setNotes] = useState([]);

  const notesCount = useMemo(() => notes.length, [notes]);

  const handleAddNote = (e) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      alert('Please add a title and note content.');
      return;
    }

    const newNote = {
      id: Date.now().toString(),
      title: title.trim(),
      content: content.trim(),
      attachmentName: attachment ? attachment.name : null,
      createdAt: new Date().toLocaleString(),
    };

    setNotes((prev) => [newNote, ...prev]);
    setTitle('');
    setContent('');
    setAttachment(null);
  };

  const handleDeleteNote = (noteId) => {
    setNotes((prev) => prev.filter((note) => note.id !== noteId));
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#090909] rounded-2xl shadow-xl p-6 border border-[#b89100]">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-5">
          <div>
            <h2 className="text-2xl font-bold text-[#ffd700]">Notes Dashboard</h2>
            <p className="text-[#f0d975] mt-1">
              Keep quick notes and attachments in the gold vault.
            </p>
          </div>
          <div className="rounded-2xl bg-[#111] px-4 py-3 text-sm text-[#ffd700] border border-[#b89100]">
            Notes saved: <span className="font-semibold">{notesCount}</span>
          </div>
        </div>

        <form onSubmit={handleAddNote} className="space-y-4">
          <div>
            <label className="block text-[#ffd700] mb-2">Title</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
              placeholder="Note title"
            />
          </div>

          <div>
            <label className="block text-[#ffd700] mb-2">Note</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={4}
              className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
              placeholder="Write your note here"
            />
          </div>

          <div>
            <label className="block text-[#ffd700] mb-2">Attachment (optional)</label>
            <input
              type="file"
              onChange={(e) => setAttachment(e.target.files?.[0] ?? null)}
              className="w-full text-sm text-[#ffd700]"
            />
            {attachment && (
              <p className="mt-2 text-sm text-[#f0d975]">
                Attached: <span className="font-semibold">{attachment.name}</span>
              </p>
            )}
          </div>

          <button
            type="submit"
            className="inline-flex items-center gap-2 bg-[#ffd700] text-black px-5 py-3 rounded-xl hover:bg-[#e6c400] transition-all"
          >
            <FilePlus className="w-5 h-5" />
            Save Note
          </button>
        </form>
      </div>

      <div className="grid gap-4">
        {notes.length === 0 ? (
          <div className="bg-[#090909] rounded-2xl shadow-xl p-8 border border-[#b89100] text-center text-[#ffd700]">
            No notes yet. Add one to start your notes dashboard.
          </div>
        ) : (
          notes.map((note) => (
            <div key={note.id} className="bg-[#090909] rounded-2xl shadow-xl p-5 border border-[#b89100]">
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-[#ffd700]">{note.title}</h3>
                  <p className="text-sm text-[#d8c57f] mt-1">{note.createdAt}</p>
                </div>
                <button
                  onClick={() => handleDeleteNote(note.id)}
                  className="inline-flex items-center gap-2 text-[#ffd700] hover:text-[#e6c400]"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
              </div>
              <p className="text-[#f0d975] whitespace-pre-line mb-3">{note.content}</p>
              {note.attachmentName && (
                <div className="rounded-xl bg-[#111] px-4 py-3 text-sm text-[#ffd700] border border-[#b89100]">
                  Attached file: <span className="font-semibold">{note.attachmentName}</span>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

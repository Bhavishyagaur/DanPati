import { Trash2, TrendingUp, TrendingDown } from 'lucide-react';

export function ExpenseItem({ expense, onDelete }) {
  const isIncome = expense.type === 'income';

  return (
    <div className={`flex items-center justify-between p-4 rounded-xl hover:shadow-lg transition-all border ${
      isIncome
        ? 'bg-[#111] border-[#b89100]'
        : 'bg-[#111] border-[#b89100]'
    }`}>
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className={`p-2 rounded-lg ${isIncome ? 'bg-[#b89100]' : 'bg-[#b89100]'}`}>
          {isIncome ? (
            <TrendingUp className="w-5 h-5 text-black" />
          ) : (
            <TrendingDown className="w-5 h-5 text-black" />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-1">
            <h3 className="text-[#ffd700] truncate">{expense.description}</h3>
            <span className={`px-3 py-1 rounded-full text-xs whitespace-nowrap shadow-sm ${
              isIncome
                ? 'bg-[#b89100] text-black'
                : 'bg-[#b89100] text-black'
            }`}>
              {expense.category}
            </span>
          </div>
          <p className="text-[#d8c57f]">{expense.date}</p>
        </div>
      </div>

      <div className="flex items-center gap-4 ml-4">
        <p className={`whitespace-nowrap ${isIncome ? 'text-[#ffd700]' : 'text-[#f0d975]'}`}>
          {isIncome ? '+' : '-'}₹{expense.amount.toFixed(2)}
        </p>
        <button
          onClick={() => onDelete(expense.id)}
          className="p-2 rounded-lg bg-[#111] hover:bg-[#1d1d1d] transition-all group"
          aria-label="Delete transaction"
        >
          <Trash2 className="w-5 h-5 text-[#ffd700] group-hover:text-[#e6c400] transition-colors" />
        </button>
      </div>
    </div>
  );
}

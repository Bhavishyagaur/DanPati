import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';

export function StatisticsCards({ totalIncome, totalExpense, remainingBalance }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
      <div className="bg-[#090909] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-[#b89100]">
        <div className="flex items-center justify-between mb-2">
          <p className="text-[#ffd700]">Total Income</p>
          <div className="p-2 rounded-lg bg-[#b89100]">
            <TrendingUp className="w-5 h-5 text-black" />
          </div>
        </div>
        <p className="text-[#ffd700]">₹{totalIncome.toFixed(2)}</p>
      </div>

      <div className="bg-[#090909] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-[#b89100]">
        <div className="flex items-center justify-between mb-2">
          <p className="text-[#ffd700]">Total Expenses</p>
          <div className="p-2 rounded-lg bg-[#b89100]">
            <TrendingDown className="w-5 h-5 text-black" />
          </div>
        </div>
        <p className="text-[#f0d975]">₹{totalExpense.toFixed(2)}</p>
      </div>

      <div className="bg-[#090909] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-[#b89100]">
        <div className="flex items-center justify-between mb-2">
          <p className="text-[#ffd700]">Remaining Balance</p>
          <div className="p-2 rounded-lg bg-[#b89100]">
            <Wallet className="w-5 h-5 text-black" />
          </div>
        </div>
        <p className={remainingBalance >= 0 ? "text-[#ffd700]" : "text-[#ffcb6b]"}>
          ₹{remainingBalance.toFixed(2)}
        </p>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { PlusCircle } from 'lucide-react';

export function ExpenseForm({ onAddTransaction }) {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [type, setType] = useState('expense');

  // DIFFERENT CATEGORIES
  const incomeCategories = [
    'Salary',
    'Freelance',
    'Business',
    'Investments',
    'Bonus',
    'Other Income',
  ];

  const expenseCategories = [
    'Food',
    'Transportation',
    'Entertainment',
    'Utilities',
    'Shopping',
    'Healthcare',
    'Bills',
    'Other Expense',
  ];

  const currentCategories =
    type === 'income'
      ? incomeCategories
      : expenseCategories;

  const handleSubmit = (e) => {
    e.preventDefault();

    if (
      !description ||
      !amount ||
      !category
    ) {
      alert('Please fill all fields');
      return;
    }

    onAddTransaction(
      description,
      parseFloat(amount),
      category,
      type
    );

    // RESET FORM
    setDescription('');
    setAmount('');
    setCategory('');
    setType('expense');
  };

  return (
    <div className="bg-[#090909] rounded-2xl shadow-xl p-6 border border-[#b89100]">
      <h2 className="text-2xl font-bold text-[#ffd700] mb-6">
        Add Transaction
      </h2>

      <form
        onSubmit={handleSubmit}
        className="space-y-4"
      >
        <div>
          <label className="block text-[#ffd700] mb-2">
            Description
          </label>

          <input
            type="text"
            value={description}
            onChange={(e) =>
              setDescription(e.target.value)
            }
            placeholder="Enter description"
            className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
            required
          />
        </div>

        <div>
          <label className="block text-[#ffd700] mb-2">
            Amount
          </label>

          <input
            type="number"
            value={amount}
            onChange={(e) =>
              setAmount(e.target.value)
            }
            placeholder="Enter amount"
            className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] placeholder:text-[#d8c57f] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
            required
          />
        </div>

        <div>
          <label className="block text-[#ffd700] mb-2">
            Transaction Type
          </label>

          <select
            value={type}
            onChange={(e) => {
              setType(e.target.value);
              setCategory('');
            }}
            className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
          >
            <option value="expense">
              Expense
            </option>

            <option value="income">
              Income
            </option>
          </select>
        </div>

        <div>
          <label className="block text-[#ffd700] mb-2">
            Category
          </label>

          <select
            value={category}
            onChange={(e) =>
              setCategory(e.target.value)
            }
            className="w-full rounded-xl border border-[#b89100] bg-[#080808] px-4 py-3 text-[#ffd700] focus:outline-none focus:ring-2 focus:ring-[#ffd700]/40"
            required
          >
            <option value="">
              Select Category
            </option>

            {currentCategories.map((cat) => (
              <option
                key={cat}
                value={cat}
                className="bg-[#090909] text-[#ffd700]"
              >
                {cat}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          className="w-full rounded-xl bg-[#ffd700] text-black px-4 py-3 font-semibold uppercase tracking-[0.03em] hover:bg-[#e6c400] transition-all flex items-center justify-center gap-2"
        >
          <PlusCircle className="w-5 h-5" />
          Add Transaction
        </button>
      </form>
    </div>
  );
}
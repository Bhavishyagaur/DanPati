import { Wallet, LogOut, User } from 'lucide-react';

export function Header({ username, onLogout }) {
  return (
    <div className="mb-8">
      <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-black shadow-[0_20px_60px_-40px_rgba(255,215,0,0.3)] border border-[#b89100]">
            <Wallet className="w-8 h-8 text-[#ffd700]" />
          </div>
          <div>
            <h1 className="text-3xl font-extrabold text-[#ffd700] tracking-tight">
              Dan Pati
            </h1>
            <p className="text-[#f5d475]">Track your moves inside the black gold vault.</p>
          </div>
        </div>

        <div className="flex flex-col items-start gap-3 sm:items-end sm:flex-row sm:items-center">
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-black shadow-md border border-[#b89100] text-[#ffd700]">
            <User className="w-5 h-5 text-[#ffd700]" />
            <span>{username}</span>
          </div>
          <button
            onClick={onLogout}
            className="px-4 py-2 rounded-xl bg-[#b89100] text-black hover:bg-[#ffd700] transition-colors flex items-center gap-2 shadow-md"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}

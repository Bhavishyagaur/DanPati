import { useState, useEffect, useMemo, useCallback } from 'react';
import { Login } from './components/Login';
import SignUpPage from './components/SignupPage';
import { Header } from './components/Header';
import { StatisticsCards } from './components/StatisticsCards';
import { ExpenseForm } from './components/ExpenseForm';
import { SavingsGoal } from './components/SavingGoal';
import { ExpenseChart } from './components/ExpenseChart';
import { ExpenseList } from './components/ExpenseList';
import { NotesDashboard } from './components/NotesDashboard';

const mockFetchTransactions = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: '1',
          description: 'Monthly Salary',
          amount: 50000,
          category: 'Salary',
          date: '2026-05-01',
          type: 'income'
        },
        {
          id: '2',
          description: 'Freelance Project',
          amount: 15000,
          category: 'Freelance',
          date: '2026-05-03',
          type: 'income'
        },
        {
          id: '3',
          description: 'Grocery Shopping',
          amount: 3500,
          category: 'Food',
          date: '2026-05-08',
          type: 'expense'
        }
      ]);
    }, 800);
  });
};

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showSignup, setShowSignup] = useState(false);
  const [username, setUsername] = useState('');
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterType, setFilterType] = useState('All');
  const [activeSection, setActiveSection] = useState('finance');

  const categories = [
    'Salary',
    'Freelance',
    'Food',
    'Transportation',
    'Entertainment',
    'Utilities',
    'Shopping',
    'Healthcare',
    'Other'
  ];

  useEffect(() => {
    if (isLoggedIn) {
      setLoading(true);

      const fetchTransactions = async () => {
        try {
          const data = await mockFetchTransactions();
          setTransactions(data);
        } catch (error) {
          console.error('Error fetching transactions:', error);
        } finally {
          setLoading(false);
        }
      };

      fetchTransactions();
    }
  }, [isLoggedIn]);

  const handleLogin = useCallback((user) => {
    setUsername(user);
    setIsLoggedIn(true);
  }, []);

  const handleLogout = useCallback(() => {
    setIsLoggedIn(false);
    setUsername('');
    setTransactions([]);
    setFilterCategory('All');
    setFilterType('All');
  }, []);

  const handleAddTransaction = useCallback(
    (description, amount, category, type) => {
      const newTransaction = {
        id: Date.now().toString(),
        description,
        amount,
        category,
        type,
        date: new Date().toISOString().split('T')[0]
      };

      setTransactions((prev) => [newTransaction, ...prev]);
    },
    []
  );

  const handleDeleteTransaction = useCallback((id) => {
    setTransactions((prev) =>
      prev.filter((transaction) => transaction.id !== id)
    );
  }, []);

  const filteredTransactions = useMemo(() => {
    return transactions.filter((transaction) => {
      const matchesCategory =
        filterCategory === 'All' ||
        transaction.category === filterCategory;

      const matchesType =
        filterType === 'All' || transaction.type === filterType;

      return matchesCategory && matchesType;
    });
  }, [transactions, filterCategory, filterType]);

  const statistics = useMemo(() => {
    const totalIncome = transactions
      .filter((t) => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalExpense = transactions
      .filter((t) => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      totalIncome,
      totalExpense,
      remainingBalance: totalIncome - totalExpense
    };
  }, [transactions]);

  // LOGIN / SIGNUP SCREEN
  if (!isLoggedIn) {
    return (
      <div className="relative">
        {showSignup ? (
          <SignUpPage />
        ) : (
          <Login onLogin={handleLogin} onShowSignup={() => setShowSignup(true)} />
        )}
      </div>
    );
  }

  // LOADING SCREEN
  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-[#b89100] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-[#ffd700]">Loading transactions...</p>
        </div>
      </div>
    );
  }

  // DASHBOARD
  return (
    <div className="min-h-screen bg-black text-[#ffd700] p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <Header username={username} onLogout={handleLogout} />

        <div className="flex flex-wrap items-center gap-3 rounded-3xl bg-[#101010]/90 border border-[#b89100] p-4 shadow-inner shadow-[#b89100]/10">
          <button
            type="button"
            onClick={() => setActiveSection('finance')}
            className={`px-4 py-2 rounded-full font-semibold transition ${
              activeSection === 'finance'
                ? 'bg-[#b89100] text-black shadow-lg shadow-[#b89100]/30'
                : 'bg-[#1a1a1a] text-[#ffd700] hover:bg-[#2c2c2c]'
            }`}
          >
            Finance Dashboard
          </button>
          <button
            type="button"
            onClick={() => setActiveSection('notes')}
            className={`px-4 py-2 rounded-full font-semibold transition ${
              activeSection === 'notes'
                ? 'bg-[#b89100] text-black shadow-lg shadow-[#b89100]/30'
                : 'bg-[#1a1a1a] text-[#ffd700] hover:bg-[#2c2c2c]'
            }`}
          >
            Notes Dashboard
          </button>
        </div>

        {activeSection === 'finance' ? (
          <div className="space-y-6">
            <StatisticsCards
              totalIncome={statistics.totalIncome}
              totalExpense={statistics.totalExpense}
              remainingBalance={statistics.remainingBalance}
            />

            <div className="grid grid-cols-1 xl:grid-cols-[2fr_1fr] gap-6">
              <ExpenseChart transactions={transactions} />
              <SavingsGoal balance={statistics.remainingBalance} />
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-[1.1fr_0.9fr] gap-6">
              <ExpenseList
                expenses={filteredTransactions}
                filterCategory={filterCategory}
                filterType={filterType}
                categories={categories}
                onFilterChange={setFilterCategory}
                onFilterTypeChange={setFilterType}
                onDeleteExpense={handleDeleteTransaction}
              />

              <ExpenseForm
                onAddTransaction={handleAddTransaction}
                categories={categories}
              />
            </div>
          </div>
        ) : (
          <NotesDashboard />
        )}
      </div>
    </div>
  );
}